-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: j7a305.p.ssafy.io    Database: gamul_db
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ingredient`
--

DROP TABLE IF EXISTS `ingredient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ingredient` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `high_class` bigint NOT NULL,
  `low_class` varchar(255) NOT NULL,
  `mid_class` varchar(255) NOT NULL,
  `views` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingredient`
--

LOCK TABLES `ingredient` WRITE;
/*!40000 ALTER TABLE `ingredient` DISABLE KEYS */;
INSERT INTO `ingredient` VALUES (1,1,'일반계','벼',0),(2,1,'일반미(쌀 일반)','쌀',0),(3,1,'찹쌀(일반)','찹쌀',0),(4,10,'양파(일반)','양파',2),(5,10,'대파(일반)','대파',0),(6,10,'쪽파(일반)','쪽파',0),(7,10,'청양','풋고추',0),(8,10,'꽈리고추(일반)','꽈리고추',0),(9,10,'양건','건고추',0),(10,10,'홍고추(일반)','홍고추',1),(11,10,'저장형 한지','마늘',0),(12,10,'생강(일반)','생강',0),(13,11,'청피망','피망(단고추)',0),(14,12,'흰깨','참깨',0),(15,12,'들깨(일반)','들깨',0),(16,12,'땅콩(일반)','땅콩',0),(17,13,'느타리버섯(일반)','느타리버섯',0),(18,13,'팽이1호','팽이버섯',0),(19,2,'백태','콩',0),(20,2,'붉은팥','팥',0),(21,2,'녹두(일반)','녹두',0),(22,6,'수박(일반)','수박',0),(23,6,'금싸라기','참외',0),(24,6,'토마토(일반)','토마토',0),(25,6,'설향','딸기',0),(26,6,'방울토마토','방울토마토',0),(27,3,'수미','감자',3),(28,3,'밤고구마','고구마',0),(29,15,'메밀(수입)','메밀',0),(30,4,'후지','사과',0),(31,4,'신고','배',0),(32,4,'캠벨얼리','포도',0),(33,4,'유명','복숭아',0),(34,4,'부유','단감',0),(35,4,'참다래(키위)일반','참다래(키위)',0),(36,4,'바나나(수입)','바나나',0),(37,4,'조생귤','감귤',0),(38,7,'취청','오이',0),(39,7,'애호박','호박',0),(40,8,'봄배추','배추',0),(41,8,'얼갈이배추','얼갈이배추',0),(42,8,'양배추(일반)','양배추',1),(43,8,'청상추','상추',7),(44,8,'열무(일반)','열무',0),(45,8,'시금치(일반)','시금치',0),(46,8,'미나리(일반)','미나리',1),(47,8,'깻잎(일반)','깻잎',0),(48,9,'봄무','무',0),(49,9,'흙당근','당근',0),(50,13,'새송이(일반)','새송이',0),(51,11,'파프리카(일반)','파프리카',0),(52,4,'레몬(수입)','레몬',0),(53,4,'네블','오렌지',0),(54,4,'자몽(수입)','자몽',0),(55,4,'아몬드(수입)','아몬드',0),(56,4,'망고(수입)','망고',0),(57,4,'건블루베리(수입)','블루베리',0),(58,6,'네트계','메론',3),(59,5,'호두(일반)','호두',0),(60,4,'파인애플(수입)','파인애플',0),(61,8,'갓(일반)','갓',0),(62,14,'고추가루','조미제품',0),(63,14,'건포도(수입)','건제품',0),(64,4,'체리(수입)','체리',0),(65,17,'오징어','오징어',4),(66,16,'쇠고기','쇠고기',0),(67,18,'달걀','달걀',0),(68,17,'명태','명태',0),(69,17,'동태','동태',0),(70,17,'조기','조기',0),(71,16,'닭고기','닭고기',0),(72,16,'돼지고기','돼지고기',0);
/*!40000 ALTER TABLE `ingredient` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07  9:57:16
